import { useState, useEffect, useRef } from "react";
import LiveMap from "./LiveMap";

const COLORS = {
  primary: "#C0392B",
  primaryDark: "#96281B",
  primaryLight: "#E74C3C",
  accent: "#FF6B6B",
  safe: "#27AE60",
  medium: "#F39C12",
  danger: "#E74C3C",
  critical: "#8E1010",
  bg: "#0D0D0D",
  card: "#1A1A1A",
  cardBorder: "#2A2A2A",
  text: "#F5F5F5",
  muted: "#888",
};

const RISK_ZONES = [
  { id: 1, name: "Majestic / KSR Station", lat: 12.9775, lng: 77.5713, risk: "critical", reason: "Major transit hub, high footfall at night, known harassment hotspot near bus stand and railway station", incidents: 142 },
  { id: 2, name: "KR Market / City Market", lat: 12.9634, lng: 77.5757, risk: "critical", reason: "Crowded wholesale market with poor lighting in interior lanes, reported molestation incidents", incidents: 118 },
  { id: 3, name: "DJ Halli", lat: 12.9986, lng: 77.6369, risk: "critical", reason: "History of civil unrest, avoid especially evenings and nights", incidents: 97 },
  { id: 4, name: "KG Halli", lat: 12.9940, lng: 77.6294, risk: "critical", reason: "High crime density area, avoid at all hours", incidents: 89 },
  { id: 5, name: "Magadi Road", lat: 12.9700, lng: 77.5390, risk: "high", reason: "Emerging unsafe corridor, brothel district, limited police visibility after dark", incidents: 76 },
  { id: 6, name: "Peenya Industrial Area", lat: 13.0297, lng: 77.5191, risk: "high", reason: "Industrial zone with poor lighting, isolated stretches, unsafe for women after 6pm", incidents: 68 },
  { id: 7, name: "Shivajinagar Market", lat: 12.9855, lng: 77.6010, risk: "high", reason: "Dense market area prone to pickpocketing, groping in crowds, chaotic environment", incidents: 63 },
  { id: 8, name: "Kalasipalya", lat: 12.9636, lng: 77.5720, risk: "high", reason: "Avoid interior lanes even during day, dense and unmonitored alleyways", incidents: 58 },
  { id: 9, name: "Okalipuram", lat: 12.9837, lng: 77.5578, risk: "high", reason: "High petty crime, unsafe stretches particularly after sundown", incidents: 52 },
  { id: 10, name: "Padarayanapura", lat: 12.9550, lng: 77.5522, risk: "high", reason: "Avoid at all times per safety advisories, gang activity reported", incidents: 47 },
  { id: 11, name: "Wilson Garden", lat: 12.9412, lng: 77.5960, risk: "high", reason: "Interior lanes unsafe at night, poor street lighting in residential pockets", incidents: 44 },
  { id: 12, name: "Outer Ring Road (Isolated)", lat: 12.9350, lng: 77.6900, risk: "medium", reason: "Certain isolated stretches have poor lighting and minimal traffic late night", incidents: 38 },
  { id: 13, name: "K Narayanapura", lat: 13.0640, lng: 77.6420, risk: "medium", reason: "Unlit streets for over 2 years, security concerns for students and women", incidents: 33 },
  { id: 14, name: "Doddanekundi", lat: 12.9767, lng: 77.7100, risk: "medium", reason: "Poorly lit stretches, safety concerns raised by women residents", incidents: 29 },
  { id: 15, name: "Jakkur", lat: 13.0700, lng: 77.5950, risk: "medium", reason: "Dark streets, limited police patrolling in residential lanes", incidents: 27 },
  { id: 16, name: "MG Road (Night)", lat: 12.9757, lng: 77.6101, risk: "medium", reason: "Molestation incidents reported during crowded events and New Year celebrations", incidents: 25 },
  { id: 17, name: "Kammanahalli", lat: 13.0186, lng: 77.6395, risk: "medium", reason: "Rapid commercialisation with unmonitored interior residential pockets", incidents: 22 },
  { id: 18, name: "Raj Bhavan Road", lat: 12.9930, lng: 77.5920, risk: "medium", reason: "Unlit streetlights in central city area, unsafe after dark", incidents: 19 },
  { id: 19, name: "Indiranagar", lat: 12.9784, lng: 77.6408, risk: "low", reason: "Generally safe, high police presence, but caution advised in isolated lanes late night", incidents: 12 },
  { id: 20, name: "Koramangala", lat: 12.9352, lng: 77.6245, risk: "low", reason: "Relatively safe, well-lit nightlife areas, stay on main streets", incidents: 10 },
  { id: 21, name: "Jayanagar", lat: 12.9308, lng: 77.5838, risk: "low", reason: "Family neighbourhood, considered one of the safer areas in Bangalore", incidents: 8 },
  { id: 22, name: "HSR Layout", lat: 12.9121, lng: 77.6446, risk: "low", reason: "Well-planned, frequent police patrols, gated communities", incidents: 7 },
  { id: 23, name: "Malleshwaram", lat: 13.0027, lng: 77.5711, risk: "low", reason: "Family-oriented, safe social culture, active community watch", incidents: 6 },
];

const RISK_CONFIG = {
  critical: { color: "#8E1010", label: "Critical Risk", dot: "#FF2D2D" },
  high: { color: "#C0392B", label: "High Risk", dot: "#FF6B35" },
  medium: { color: "#E67E22", label: "Medium Risk", dot: "#F5A623" },
  low: { color: "#27AE60", label: "Safe Zone", dot: "#2ECC71" },
};

const FEATURES = [
  { id: "home", icon: "🏠", label: "Home" },
  { id: "map", icon: "🗺️", label: "Map" },
  { id: "community", icon: "👥", label: "Community" },
  { id: "help", icon: "🆘", label: "Help" },
  { id: "settings", icon: "⚙️", label: "Settings" },
];

function SOSButton({ onActivate }) {
  const [held, setHeld] = useState(false);
  const [progress, setProgress] = useState(0);
  const [activated, setActivated] = useState(false);
  const interval = useRef(null);

  const startHold = () => {
    setHeld(true);
    interval.current = setInterval(() => {
      setProgress(p => {
        if (p >= 100) {
          clearInterval(interval.current);
          setActivated(true);
          onActivate();
          return 100;
        }
        return p + 5;
      });
    }, 80);
  };

  const endHold = () => {
    if (!activated) {
      setHeld(false);
      setProgress(0);
      clearInterval(interval.current);
    }
  };

  const reset = () => {
    setActivated(false);
    setProgress(0);
    setHeld(false);
  };

  const circumference = 2 * Math.PI * 54;

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12 }}>
      {activated && (
        <div style={{ background: "#E74C3C22", border: "1px solid #E74C3C55", borderRadius: 12, padding: "8px 20px", fontSize: 13, color: "#FF6B6B", textAlign: "center" }}>
          🚨 Alert sent to 3 contacts + Police
        </div>
      )}
      <div
        style={{ position: "relative", width: 140, height: 140, cursor: "pointer", userSelect: "none" }}
        onMouseDown={startHold}
        onMouseUp={endHold}
        onMouseLeave={endHold}
        onTouchStart={startHold}
        onTouchEnd={endHold}
      >
        <svg width="140" height="140" style={{ position: "absolute", top: 0, left: 0, transform: "rotate(-90deg)" }}>
          <circle cx="70" cy="70" r="54" fill="none" stroke="#2A2A2A" strokeWidth="6" />
          <circle
            cx="70" cy="70" r="54"
            fill="none"
            stroke={activated ? "#27AE60" : "#E74C3C"}
            strokeWidth="6"
            strokeDasharray={circumference}
            strokeDashoffset={circumference - (progress / 100) * circumference}
            strokeLinecap="round"
            style={{ transition: "stroke-dashoffset 0.08s linear" }}
          />
        </svg>
        <div
          style={{
            position: "absolute", top: "50%", left: "50%",
            transform: "translate(-50%, -50%)",
            width: 100, height: 100, borderRadius: "50%",
            background: activated ? "linear-gradient(135deg, #27AE60, #1E8449)" : held ? "linear-gradient(135deg, #C0392B, #8E1010)" : "linear-gradient(135deg, #E74C3C, #C0392B)",
            display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
            boxShadow: held ? `0 0 30px ${COLORS.accent}66` : "0 4px 20px #E74C3C33",
            transition: "all 0.2s",
          }}
        >
          <span style={{ fontSize: 28 }}>{activated ? "✅" : "🆘"}</span>
          <span style={{ fontSize: 11, fontWeight: 700, color: "#fff", letterSpacing: 2 }}>
            {activated ? "SENT" : "SOS"}
          </span>
        </div>
      </div>
      <p style={{ fontSize: 12, color: COLORS.muted, margin: 0 }}>
        {activated ? <span style={{ color: "#27AE60", cursor: "pointer" }} onClick={reset}>Tap to dismiss</span> : "Hold 3 seconds to activate"}
      </p>
    </div>
  );
}

function HomeScreen() {
  const [sosTriggered, setSosTriggered] = useState(false);
  const [locationSharing, setLocationSharing] = useState(false);
  const [checkinActive, setCheckinActive] = useState(false);
  const [checkinTime, setCheckinTime] = useState(30);

  return (
    <div style={{ padding: "0 0 20px" }}>
      <div style={{ textAlign: "center", padding: "24px 0 16px" }}>
        <p style={{ fontSize: 13, color: COLORS.muted, margin: "0 0 4px" }}>Good evening, Priya 👋</p>
        <h2 style={{ fontSize: 20, color: COLORS.text, margin: 0, fontWeight: 600 }}>Stay safe, stay connected</h2>
      </div>

      <div style={{ display: "flex", justifyContent: "center", padding: "16px 0 24px" }}>
        <SOSButton onActivate={() => setSosTriggered(true)} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, padding: "0 16px" }}>
        {[
          {
            title: "Live Location", icon: "📍", active: locationSharing,
            desc: locationSharing ? "Sharing with 3 contacts" : "Tap to share location",
            toggle: () => setLocationSharing(v => !v),
            color: locationSharing ? COLORS.safe : COLORS.muted,
          },
          {
            title: "Fake Call", icon: "📞", active: false,
            desc: "Simulate incoming call",
            toggle: () => alert("Fake call triggered!"),
            color: "#3498DB",
          },
          {
            title: "Safe Route", icon: "🛡️", active: false,
            desc: "Find lit, monitored paths",
            toggle: () => {},
            color: "#9B59B6",
          },
          {
            title: "Check-in Timer", icon: "⏱️", active: checkinActive,
            desc: checkinActive ? `Auto-alert in ${checkinTime}m` : "Set safety timer",
            toggle: () => setCheckinActive(v => !v),
            color: checkinActive ? COLORS.danger : COLORS.muted,
          },
        ].map(f => (
          <div
            key={f.title}
            onClick={f.toggle}
            style={{
              background: COLORS.card,
              border: `1px solid ${f.active ? f.color + "55" : COLORS.cardBorder}`,
              borderRadius: 14,
              padding: "14px 12px",
              cursor: "pointer",
              transition: "all 0.2s",
            }}
          >
            <div style={{ fontSize: 22, marginBottom: 6 }}>{f.icon}</div>
            <div style={{ fontSize: 13, fontWeight: 600, color: f.active ? f.color : COLORS.text, marginBottom: 3 }}>{f.title}</div>
            <div style={{ fontSize: 11, color: COLORS.muted }}>{f.desc}</div>
          </div>
        ))}
      </div>

      <div style={{ margin: "20px 16px 0", background: COLORS.card, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 14, padding: "14px" }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: COLORS.text, marginBottom: 10 }}>⚡ Trusted Contacts</div>
        {[
          { name: "Mom", phone: "+91 98760 12345", initial: "M", color: "#E74C3C" },
          { name: "Riya (Friend)", phone: "+91 87654 32109", initial: "R", color: "#9B59B6" },
          { name: "Bangalore Police", phone: "100", initial: "🚔", color: "#2980B9" },
        ].map(c => (
          <div key={c.name} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
            <div style={{ width: 32, height: 32, borderRadius: "50%", background: c.color + "33", border: `1px solid ${c.color}55`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, flexShrink: 0 }}>{c.initial}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, color: COLORS.text }}>{c.name}</div>
              <div style={{ fontSize: 11, color: COLORS.muted }}>{c.phone}</div>
            </div>
            <div style={{ fontSize: 18, color: COLORS.safe }}>📞</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function HeatmapPoint({ zone, mapBounds, mapW, mapH, onClick }) {
  const x = ((zone.lng - mapBounds.minLng) / (mapBounds.maxLng - mapBounds.minLng)) * mapW;
  const y = ((mapBounds.maxLat - zone.lat) / (mapBounds.maxLat - mapBounds.minLat)) * mapH;
  const cfg = RISK_CONFIG[zone.risk];
  const sizes = { critical: 22, high: 18, medium: 14, low: 10 };
  const r = sizes[zone.risk];

  return (
    <g onClick={() => onClick(zone)} style={{ cursor: "pointer" }}>
      <circle cx={x} cy={y} r={r * 2} fill={cfg.color} opacity={0.15} />
      <circle cx={x} cy={y} r={r * 1.2} fill={cfg.color} opacity={0.3} />
      <circle cx={x} cy={y} r={r * 0.6} fill={cfg.dot} opacity={0.9} />
    </g>
  );
}

function MapScreen() {
  const [selected, setSelected] = useState(null);
  const [filter, setFilter] = useState("all");

  const mapBounds = { minLat: 12.88, maxLat: 13.10, minLng: 77.50, maxLng: 77.75 };
  const mapW = 360;
  const mapH = 340;

  const filtered = RISK_ZONES.filter(z => filter === "all" || z.risk === filter);

  return (
    <div style={{ padding: "0 0 16px" }}>
      <div style={{ padding: "16px 16px 8px" }}>
        <h3 style={{ fontSize: 16, color: COLORS.text, margin: "0 0 4px", fontWeight: 600 }}>Bangalore Safety Heatmap</h3>
        <p style={{ fontSize: 12, color: COLORS.muted, margin: 0 }}>Based on NCRB data, NARI 2025 survey & community reports</p>
      </div>

      <div style={{ display: "flex", gap: 6, padding: "0 16px 12px", overflowX: "auto" }}>
        {["all", "critical", "high", "medium", "low"].map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            style={{
              padding: "4px 12px", borderRadius: 20, fontSize: 11, fontWeight: 600,
              cursor: "pointer", whiteSpace: "nowrap", border: "none",
              background: filter === f ? (f === "all" ? COLORS.primaryLight : RISK_CONFIG[f]?.color || COLORS.primaryLight) : "#2A2A2A",
              color: filter === f ? "#fff" : COLORS.muted,
            }}
          >
            {f === "all" ? "All Zones" : RISK_CONFIG[f].label}
          </button>
        ))}
      </div>

      <div style={{ margin: "0 16px", borderRadius: 14, overflow: "hidden", border: `1px solid ${COLORS.cardBorder}`, position: "relative", background: "#111" }}>
        <svg width="100%" viewBox={`0 0 ${mapW} ${mapH}`} style={{ display: "block", background: "#0D1B2A" }}>
          <defs>
            <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
              <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#1A2A3A" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width={mapW} height={mapH} fill="url(#grid)" />
          <text x="180" y="30" textAnchor="middle" fontSize="11" fill="#334" fontWeight="500">BANGALORE</text>
          <text x="180" y="44" textAnchor="middle" fontSize="9" fill="#2A3A4A">Women Safety Risk Map</text>
          {[
            { name: "City Center", x: 150, y: 170 },
            { name: "North", x: 180, y: 60 },
            { name: "East", x: 310, y: 180 },
            { name: "South", x: 180, y: 300 },
            { name: "West", x: 60, y: 180 },
          ].map(l => (
            <text key={l.name} x={l.x} y={l.y} textAnchor="middle" fontSize="9" fill="#253545" fontWeight="500">{l.name}</text>
          ))}
          {filtered.map(zone => (
            <HeatmapPoint key={zone.id} zone={zone} mapBounds={mapBounds} mapW={mapW} mapH={mapH} onClick={setSelected} />
          ))}
        </svg>

        <div style={{ position: "absolute", bottom: 8, right: 8, background: "#0D0D0Dcc", borderRadius: 8, padding: "6px 8px" }}>
          {Object.entries(RISK_CONFIG).map(([k, v]) => (
            <div key={k} style={{ display: "flex", alignItems: "center", gap: 5, marginBottom: 3 }}>
              <div style={{ width: 8, height: 8, borderRadius: "50%", background: v.dot }} />
              <span style={{ fontSize: 10, color: COLORS.muted }}>{v.label}</span>
            </div>
          ))}
        </div>
      </div>

      {selected && (
        <div style={{ margin: "12px 16px 0", background: COLORS.card, border: `1px solid ${RISK_CONFIG[selected.risk].color}44`, borderRadius: 14, padding: "14px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
            <div>
              <div style={{ fontSize: 14, fontWeight: 700, color: COLORS.text }}>{selected.name}</div>
              <div style={{ display: "inline-block", background: RISK_CONFIG[selected.risk].color + "33", color: RISK_CONFIG[selected.risk].dot, fontSize: 11, padding: "2px 8px", borderRadius: 10, marginTop: 4 }}>
                {RISK_CONFIG[selected.risk].label}
              </div>
            </div>
            <button onClick={() => setSelected(null)} style={{ background: "none", border: "none", color: COLORS.muted, fontSize: 18, cursor: "pointer", padding: 0 }}>✕</button>
          </div>
          <p style={{ fontSize: 12, color: "#ccc", margin: "0 0 8px", lineHeight: 1.5 }}>{selected.reason}</p>
          <div style={{ fontSize: 11, color: COLORS.muted }}>📊 {selected.incidents} incidents reported (2023–2024)</div>
        </div>
      )}

      <div style={{ margin: "12px 16px 0" }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: COLORS.text, marginBottom: 8 }}>⚠️ High-Risk Areas Summary</div>
        {RISK_ZONES.filter(z => z.risk === "critical" || z.risk === "high").slice(0, 6).map(z => (
          <div
            key={z.id}
            onClick={() => setSelected(z)}
            style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 0", borderBottom: `1px solid ${COLORS.cardBorder}`, cursor: "pointer" }}
          >
            <div style={{ width: 8, height: 8, borderRadius: "50%", background: RISK_CONFIG[z.risk].dot, flexShrink: 0 }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, color: COLORS.text }}>{z.name}</div>
              <div style={{ fontSize: 11, color: COLORS.muted }}>{z.incidents} incidents</div>
            </div>
            <div style={{ fontSize: 11, color: RISK_CONFIG[z.risk].dot, background: RISK_CONFIG[z.risk].color + "22", padding: "2px 8px", borderRadius: 10 }}>
              {z.risk}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function CommunityScreen() {
  const [reports] = useState([
    { area: "Majestic Bus Stand", time: "2h ago", type: "Harassment", severity: "high", user: "Ananya K." },
    { area: "Peenya Industrial", time: "4h ago", type: "Unsafe lighting", severity: "medium", user: "Meera R." },
    { area: "KG Halli", time: "6h ago", type: "Threatening behaviour", severity: "high", user: "Divya S." },
    { area: "ORR stretch, Marathahalli", time: "Yesterday", type: "Stalking", severity: "high", user: "Lakshmi P." },
    { area: "Shivajinagar Market", time: "Yesterday", type: "Pickpocketing", severity: "medium", user: "Sana A." },
  ]);

  return (
    <div style={{ padding: "16px" }}>
      <h3 style={{ fontSize: 16, color: COLORS.text, margin: "0 0 4px", fontWeight: 600 }}>Community Reports</h3>
      <p style={{ fontSize: 12, color: COLORS.muted, margin: "0 0 16px" }}>Real-time incident flags from verified users</p>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>
        {[
          { label: "Reports Today", value: "23", icon: "📋" },
          { label: "Areas Flagged", value: "11", icon: "📍" },
          { label: "Verified Users", value: "1.2K", icon: "✅" },
          { label: "Response Rate", value: "87%", icon: "🚔" },
        ].map(s => (
          <div key={s.label} style={{ background: COLORS.card, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 12, padding: "12px" }}>
            <div style={{ fontSize: 20, marginBottom: 4 }}>{s.icon}</div>
            <div style={{ fontSize: 22, fontWeight: 700, color: COLORS.text }}>{s.value}</div>
            <div style={{ fontSize: 11, color: COLORS.muted }}>{s.label}</div>
          </div>
        ))}
      </div>

      {reports.map((r, i) => (
        <div key={i} style={{ background: COLORS.card, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 12, padding: "12px", marginBottom: 10 }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
            <span style={{ fontSize: 13, fontWeight: 600, color: COLORS.text }}>{r.area}</span>
            <span style={{ fontSize: 11, color: COLORS.muted }}>{r.time}</span>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <span style={{
              fontSize: 11, padding: "2px 8px", borderRadius: 10,
              background: r.severity === "high" ? "#E74C3C22" : "#F39C1222",
              color: r.severity === "high" ? "#FF6B6B" : "#F5A623",
            }}>{r.type}</span>
            <span style={{ fontSize: 11, color: COLORS.muted }}>by {r.user}</span>
          </div>
        </div>
      ))}

      <button style={{ width: "100%", padding: "12px", background: COLORS.primaryLight, border: "none", borderRadius: 12, color: "#fff", fontSize: 14, fontWeight: 600, cursor: "pointer", marginTop: 8 }}>
        + Report an Incident
      </button>
    </div>
  );
}

function HelpScreen() {
  return (
    <div style={{ padding: "16px" }}>
      <h3 style={{ fontSize: 16, color: COLORS.text, margin: "0 0 4px", fontWeight: 600 }}>Emergency Help</h3>
      <p style={{ fontSize: 12, color: COLORS.muted, margin: "0 0 16px" }}>One-tap access to emergency services</p>

      {[
        { name: "Police", number: "100", icon: "🚔", color: "#2980B9" },
        { name: "Women Helpline", number: "1091", icon: "👩‍💼", color: "#8E44AD" },
        { name: "Emergency (All)", number: "112", icon: "🚨", color: "#E74C3C" },
        { name: "Ambulance", number: "108", icon: "🚑", color: "#27AE60" },
        { name: "Childline", number: "1098", icon: "👧", color: "#E67E22" },
        { name: "Cyber Crime", number: "1930", icon: "💻", color: "#16A085" },
      ].map(h => (
        <div key={h.name} style={{ display: "flex", alignItems: "center", gap: 12, background: COLORS.card, border: `1px solid ${h.color}33`, borderRadius: 12, padding: "14px", marginBottom: 10 }}>
          <div style={{ fontSize: 24 }}>{h.icon}</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 600, color: COLORS.text }}>{h.name}</div>
            <div style={{ fontSize: 13, color: h.color, fontWeight: 700 }}>{h.number}</div>
          </div>
          <button style={{ background: h.color + "22", border: `1px solid ${h.color}55`, color: h.color, borderRadius: 20, padding: "6px 14px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Call</button>
        </div>
      ))}
    </div>
  );
}

export default function App() {
  const [activeTab, setActiveTab] = useState("home");

  return (
    <div style={{ display: "flex", justifyContent: "center", padding: "20px 0", background: "transparent" }}>
      <div style={{
        width: 380,
        height: 700,
        background: COLORS.bg,
        borderRadius: 32,
        border: `2px solid #2A2A2A`,
        overflow: "hidden",
        display: "flex", flexDirection: "column",
        fontFamily: "'DM Sans', sans-serif",
        boxShadow: "0 20px 60px #00000099",
      }}>
        <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet" />

        {/* Header */}
        <div style={{ background: "#111", padding: "16px 20px 12px", borderBottom: `1px solid #1E1E1E`, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <div style={{ fontSize: 20, fontWeight: 800, color: COLORS.accent, letterSpacing: -0.5 }}>♀ Shakti</div>
            <div style={{ fontSize: 10, color: COLORS.muted, letterSpacing: 2 }}>WOMEN SAFETY PLATFORM</div>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <div style={{ width: 8, height: 8, borderRadius: "50%", background: COLORS.safe }} />
            <div style={{ fontSize: 11, color: COLORS.safe }}>Protected</div>
          </div>
        </div>

        {/* Content */}
        <div 
        style={{ 
          flex: 1, 
          overflow: activeTab === "map" ? "hidden" : "auto",
          position: "relative"
        }}>
          {activeTab === "home" && <HomeScreen />}
          {activeTab === "map" && (
            <div
              style={{
              height: "100%",
              width: "100%",
              flex: 1,
              position: "relative"
    }}
  >
    <LiveMap />
  </div>
)}
  
          {activeTab === "community" && <CommunityScreen />}
          {activeTab === "help" && <HelpScreen />}
          {activeTab === "settings" && (
            <div style={{ padding: 24, color: COLORS.muted, textAlign: "center", fontSize: 14 }}>
              Settings panel — profile, notifications, privacy
            </div>
          )}
        </div>

        {/* Bottom Nav */}
        <div style={{ background: "#111", borderTop: `1px solid #1E1E1E`, padding: "8px 0", display: "flex" }}>
          {FEATURES.map(f => (
            <button
              key={f.id}
              onClick={() => setActiveTab(f.id)}
              style={{
                flex: 1, background: "none", border: "none",
                display: "flex", flexDirection: "column", alignItems: "center", gap: 2,
                cursor: "pointer", padding: "6px 0",
              }}
            >
              <span style={{ fontSize: 18 }}>{f.icon}</span>
              <span style={{ fontSize: 10, color: activeTab === f.id ? COLORS.accent : COLORS.muted, fontWeight: activeTab === f.id ? 600 : 400 }}>
                {f.label}
              </span>
              {activeTab === f.id && <div style={{ width: 20, height: 2, background: COLORS.accent, borderRadius: 1 }} />}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}